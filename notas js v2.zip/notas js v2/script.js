
var parcial = Number(prompt("deme su nota"));
var parcial = Number(prompt("deme su nota"));
var parcial = Number(prompt("deme su nota"));
var parcial = Number(prompt("deme su nota"));
var parcial = Number(prompt("deme su nota"));
var promedio =(parcial)/5;

while (parcial >= 0) {
    
    while(parcial < 1.0){
        alert("la minima es de 1.0");
        var parcial = Number(prompt("deme su nota"));
    }
    while(parcial > 5.0) {
        alert("la maxima es de 5.0");
        var parcial = Number(prompt("deme su nota"));
    }    
    if(promedio > 2.9){
        alert("El promedio de "+parcial+" es de DESAPROBADO"); 
        break
    }
    if(promedio < 3.0){
        alert("El promedio de "+parcial+" es de APROBADO"); 
        break
    }
}